export { default as NavBar } from './layout/NavBar';
export { default as Footer } from './layout/Footer';
export { default as PrimaryBtn } from './Buttons/PrimaryBtn';
export { default as SecondaryBtn } from './Buttons/SecondaryBtn';
export { default as OutlineBtnDark } from './Buttons/OutlineBtnDark';
export { default as StoryCard } from './cards/Story';
export { default as ServiceCard } from './cards/Service';
import React from 'react'

const PrimaryBtn = ({ text }) => {
    return (
        <button className='btn primaryBtn'>{text}</button>
    )
}

export default PrimaryBtn

import React from 'react'

const SecondaryBtn = ({ text }) => {
    return (
        <button className='btn secondaryBtn'>{text}</button>
    )
}

export default SecondaryBtn